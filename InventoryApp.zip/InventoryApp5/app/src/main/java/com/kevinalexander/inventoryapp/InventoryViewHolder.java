package com.kevinalexander.inventoryapp;

public class InventoryViewHolder {
}
