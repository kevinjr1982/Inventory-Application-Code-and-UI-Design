package com.kevinalexander.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryApp.db";
    private static final String USER_TABLE = "users";
    private static final String INVENTORY_TABLE = "inventory";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create table for users
        db.execSQL("CREATE TABLE " + USER_TABLE + " (username TEXT PRIMARY KEY, password TEXT)");

        // Create table for inventory items
        db.execSQL("CREATE TABLE " + INVENTORY_TABLE + " (item_name TEXT PRIMARY KEY, quantity INTEGER, location TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop existing tables if they exist
        db.execSQL("DROP TABLE IF EXISTS " + USER_TABLE);
        db.execSQL("DROP TABLE IF EXISTS " + INVENTORY_TABLE);
        onCreate(db);
    }

    // Method to validate user login
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + USER_TABLE + " WHERE username=? AND password=?", new String[]{username, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Method to register a new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);
        long result = db.insert(USER_TABLE, null, values);
        return result != -1;
    }

    // Method to retrieve all inventory items
    public Cursor getAllInventoryItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + INVENTORY_TABLE, null); // Query to get all rows
    }

    // Method to delete an inventory item
    public boolean deleteInventoryItem(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(INVENTORY_TABLE, "item_name=?", new String[]{name});
        return result > 0; // Return true if a row was deleted
    }

    // Method to update inventory item details
    public boolean updateInventoryItem(String name, int quantity, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("quantity", quantity);
        values.put("location", location);
        int result = db.update(INVENTORY_TABLE, values, "item_name=?", new String[]{name});
        return result > 0; // Return true if a row was updated
    }

    // Method to insert a new inventory item
    public boolean insertInventoryItem(String name, int quantity, String location) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("item_name", name);
        values.put("quantity", quantity);
        values.put("location", location);
        long result = db.insert(INVENTORY_TABLE, null, values);
        return result != -1; // Return true if the insert was successful
    }
}
