package com.kevinalexander.inventoryapp;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 1;
    private TextView smsStatusText;
    private Button sendSmsButton;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        smsStatusText = findViewById(R.id.smsStatusText);
        Button requestPermissionButton = findViewById(R.id.requestPermissionButton);
        sendSmsButton = findViewById(R.id.sendSmsButton);

        // Check SMS permission on app start
        checkSmsPermission();

        // Request SMS permission
        requestPermissionButton.setOnClickListener(v -> requestSmsPermission());

        // Send SMS
        sendSmsButton.setOnClickListener(v -> sendSmsNotification());
    }

    // Method to check SMS permission
    @SuppressLint("SetTextI18n")
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsStatusText.setText("SMS Permission Status: Granted");
            sendSmsButton.setEnabled(true);
        } else {
            smsStatusText.setText("SMS Permission Status: Denied");
            sendSmsButton.setEnabled(false);
        }
    }

    // Method to request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        } else {
            Toast.makeText(this, "Permission already granted!", Toast.LENGTH_SHORT).show();
        }
    }

    // Callback for permission result
    @SuppressLint("SetTextI18n")
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();
                smsStatusText.setText("SMS Permission Status: Granted");
                sendSmsButton.setEnabled(true);
            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                smsStatusText.setText("SMS Permission Status: Denied");
                sendSmsButton.setEnabled(false);
            }
        }
    }

    // Method to send SMS notification
    private void sendSmsNotification() {
        String phoneNumber = "1234567890"; // Replace with the actual recipient's phone number
        String message = "Low Inventory Alert! Please restock items soon.";

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent Successfully!", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "SMS Sending Failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
