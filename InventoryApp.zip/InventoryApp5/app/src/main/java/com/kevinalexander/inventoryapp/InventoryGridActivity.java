package com.kevinalexander.inventoryapp;

import android.app.Activity;

public class InventoryGridActivity extends Activity {
}
